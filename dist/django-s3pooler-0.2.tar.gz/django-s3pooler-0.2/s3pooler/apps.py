from django.apps import AppConfig
    

class S3PoolerConfig(AppConfig):
    name = 's3pooler'
